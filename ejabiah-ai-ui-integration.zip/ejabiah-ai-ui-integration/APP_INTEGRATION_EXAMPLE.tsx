// Use this pattern inside your existing App.tsx after agentMetadata is loaded.
// Keep your authentication, getAccessToken, /api/agent call and AgentChat unchanged.

import { EjabiahShell } from './components/ejabiah/EjabiahShell';

// Inside <AuthenticatedTemplate>:
<EjabiahShell
  userName="Adil AlAmmari"
  userRole="IT Manager"
  notificationCount={3}
  isConversationActive={chat.messages.length > 0}
  onNewChat={() => {/* call the existing new-chat action */}}
  onQuickAction={(prompt) => {/* call the existing ChatService.sendMessage(prompt, ...) */}}
  onSignOut={() => {/* call msal instance logoutRedirect() */}}
>
  <AgentChat
    agentId={agentMetadata.id}
    agentName="Ejabiah AI"
    agentDescription="Secure Enterprise AI Assistant"
    agentLogo="/images/Ejabiah_Mark.png"
    starterPrompts={[
      'Company Policies',
      'Ask About Procedures',
      'IT & Technical Support',
    ]}
  />
</EjabiahShell>
