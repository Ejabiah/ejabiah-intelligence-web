import { useMemo, useState, type ReactNode } from 'react';
import { Icon } from './Icon';
import styles from './EjabiahShell.module.css';

type QuickAction = { id: string; title: string; description: string; icon: 'book' | 'gear' | 'laptop'; prompt: string };

interface EjabiahShellProps {
  children: ReactNode;
  userName?: string;
  userRole?: string;
  notificationCount?: number;
  isConversationActive?: boolean;
  onNewChat?: () => void;
  onQuickAction?: (prompt: string) => void;
  onSignOut?: () => void;
}

const actions: QuickAction[] = [
  { id: 'policies', title: 'Company Policies', description: 'Find approved policies, guidelines and internal regulations.', icon: 'book', prompt: 'Show me the company policies I can search.' },
  { id: 'procedures', title: 'Ask About Procedures', description: 'Get clear, step-by-step guidance on internal procedures.', icon: 'gear', prompt: 'Help me find an internal company procedure.' },
  { id: 'support', title: 'IT & Technical Support', description: 'Get assistance with systems, access and technical issues.', icon: 'laptop', prompt: 'I need IT and technical support.' },
];

export function EjabiahShell({
  children,
  userName = 'Adil AlAmmari',
  userRole = 'IT Manager',
  notificationCount = 0,
  isConversationActive = false,
  onNewChat,
  onQuickAction,
  onSignOut,
}: EjabiahShellProps) {
  const [active, setActive] = useState('home');
  const [collapsed, setCollapsed] = useState(false);
  const initials = useMemo(() => userName.split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase(), [userName]);

  const navigate = (key: string) => {
    setActive(key);
    if (key === 'new-chat') onNewChat?.();
  };

  return (
    <div className={styles.shell}>
      <aside className={`${styles.sidebar} ${collapsed ? styles.collapsed : ''}`}>
        <button className={styles.logoButton} onClick={() => setCollapsed((value) => !value)} aria-label="Toggle navigation">
          <img src="/images/Ejabiah_Mark-White_Gradient.png" alt="Ejabiah" />
        </button>
        <nav className={styles.nav} aria-label="Primary navigation">
          {[
            ['home', 'Home', 'home'],
            ['new-chat', 'New Chat', 'chat'],
            ['history', 'History', 'history'],
            ['bookmarks', 'Bookmarks', 'bookmark'],
            ['settings', 'Settings', 'settings'],
          ].map(([key, label, icon]) => (
            <button key={key} className={`${styles.navItem} ${active === key ? styles.active : ''}`} onClick={() => navigate(key)}>
              <Icon name={icon as 'home'} />
              {!collapsed && <span>{label}</span>}
            </button>
          ))}
        </nav>
        <button className={styles.help}><Icon name="help" />{!collapsed && <span>Help</span>}</button>
      </aside>

      <main className={styles.main}>
        <header className={styles.topbar}>
          <div className={styles.profile}>
            <div className={styles.avatar}>{initials}<span /></div>
            <div><small>Welcome back,</small><strong>{userName}</strong><span>{userRole}</span></div>
          </div>
          <div className={styles.topActions}>
            <button className={styles.iconButton} aria-label="Notifications"><Icon name="bell" />{notificationCount > 0 && <b>{notificationCount}</b>}</button>
            <button className={styles.signOut} onClick={onSignOut}><Icon name="signOut" /><span>Sign out</span></button>
          </div>
        </header>

        {!isConversationActive && (
          <section className={styles.dashboard}>
            <div className={styles.hero}>
              <div className={styles.heroGlow} />
              <div className={styles.brand}>
                <img src="/images/Ejabiah_Mark.png" alt="Ejabiah AI" />
                <div><span className={styles.arabic}>الإيجابية</span><span className={styles.english}>EJABIAH</span></div>
                <i />
                <b>AI</b>
              </div>
            </div>
            <div className={styles.welcome}><h1>Welcome to <span>Ejabiah AI</span></h1><p>Secure Enterprise AI Assistant</p></div>
            <div className={styles.cards}>
              {actions.map((action) => <button key={action.id} onClick={() => onQuickAction?.(action.prompt)} className={styles.card}><span><Icon name={action.icon} /></span><h2>{action.title}</h2><p>{action.description}</p><i>→</i></button>)}
            </div>
            <div className={styles.trust}>
              {[
                ['shield', 'Secure & Trusted', 'Enterprise-grade security'],
                ['lock', 'Private & Confidential', 'Protected company knowledge'],
                ['cpu', 'AI Powered', 'Smart, fast and grounded'],
                ['check', 'Always Available', 'Ready when employees need it'],
              ].map(([icon, title, subtitle]) => <div key={title}><Icon name={icon as 'shield'} /><span><strong>{title}</strong><small>{subtitle}</small></span></div>)}
            </div>
          </section>
        )}

        <section className={`${styles.chatHost} ${isConversationActive ? styles.chatActive : ''}`}>{children}</section>
      </main>
    </div>
  );
}
